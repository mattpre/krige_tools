class krige_tools:
    def __init__(self):
        self.name = 'lkjk'
